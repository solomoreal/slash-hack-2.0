-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 28, 2017 at 02:29 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `slash_hack`
--

-- --------------------------------------------------------

--
-- Table structure for table `share_story`
--

CREATE TABLE IF NOT EXISTS `share_story` (
  `story_id` varchar(15) NOT NULL,
  `passport` varchar(30) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `story` varchar(20000) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`story_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `share_story`
--

INSERT INTO `share_story` (`story_id`, `passport`, `email`, `first_name`, `last_name`, `phone`, `story`, `date`) VALUES
('story/0001', '', 'jackson@gmail.com', 'uche', 'Ikeogu', '09087654334', '                            \r\n                              help me oooo  \r\n                            ', '2017-11-25 07:41:45'),
('story/002', '', 'chidibaby@gmail.com', 'uche', 'Ikeogu', '09087654334', 'this is a fucking case ooooo!\r\na woman assulting a man                            \r\n                                \r\n                            ', '2017-11-25 07:45:16'),
('story/003', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 18:01:32'),
('story/004', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 18:04:27'),
('story/005', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 19:45:03'),
('story/006', '', 'kalu@gmail.com', 'emmanuel', 'Ikeogu', '09021805432', 'hello how are u                            \r\n                                \r\n                            ', '2017-11-26 07:05:30'),
('story/007', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-26 22:44:10'),
('', '', 'jackson@gmail.com', 'ikeogu', 'Ikeogu', '09087654334', 'just testing                        \r\n                       ', '2017-11-27 13:20:11'),
('story/008', 'story_008.jpeg', 'chidibaby@gmail.com', 'emmanuel', 'Cena', '09087654334', 'testing two                        \r\n                       ', '2017-11-27 14:18:22'),
('story/009', 'story_009.jpeg', 'jackson@gmail.com', 'ikeogu', 'aderson', '09021805432', 'i have a confession to make                        \r\n                       ', '2017-11-27 14:33:16');
