-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 28, 2017 at 02:02 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `slash_hack`
--

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE IF NOT EXISTS `partners` (
  `partner_id` varchar(50) NOT NULL,
  `role` varchar(30) NOT NULL,
  `name` varchar(55) NOT NULL,
  `email` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `interest` varchar(100) NOT NULL,
  `passport` varchar(40) NOT NULL,
  `password` varchar(35) NOT NULL,
  `website` varchar(30) NOT NULL,
  `aboutme` varchar(200) NOT NULL,
  PRIMARY KEY (`partner_id`),
  UNIQUE KEY `intrest` (`interest`),
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`partner_id`, `role`, `name`, `email`, `location`, `interest`, `passport`, `password`, `website`, `aboutme`) VALUES
('PRTN/001', 'Orgainisation', 'recheal chinyere adamma', 'chidibaby@gmail.com', '786 BDA new layout lagos', 'Domestic Violence', 'PRTN_001.jpeg', '81dc9bdb52d04dc20036dbd8313ed055', 'www.vanguardnews.org', 'fhjfhjdhfjsdhjhgjhsgjahjahga');

-- --------------------------------------------------------

--
-- Table structure for table `share_story`
--

CREATE TABLE IF NOT EXISTS `share_story` (
  `story_id` varchar(15) NOT NULL,
  `passport` varchar(30) NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `story` varchar(20000) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`story_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `share_story`
--

INSERT INTO `share_story` (`story_id`, `passport`, `email`, `first_name`, `last_name`, `phone`, `story`, `date`) VALUES
('story/0001', '', 'jackson@gmail.com', 'uche', 'Ikeogu', '09087654334', '                            \r\n                              help me oooo  \r\n                            ', '2017-11-25 07:41:45'),
('story/002', '', 'chidibaby@gmail.com', 'uche', 'Ikeogu', '09087654334', 'this is a fucking case ooooo!\r\na woman assulting a man                            \r\n                                \r\n                            ', '2017-11-25 07:45:16'),
('story/003', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 18:01:32'),
('story/004', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 18:04:27'),
('story/005', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-25 19:45:03'),
('story/006', '', 'kalu@gmail.com', 'emmanuel', 'Ikeogu', '09021805432', 'hello how are u                            \r\n                                \r\n                            ', '2017-11-26 07:05:30'),
('story/007', '', NULL, NULL, NULL, NULL, '                            \r\n                                \r\n                            ', '2017-11-26 22:44:10'),
('', '', 'jackson@gmail.com', 'ikeogu', 'Ikeogu', '09087654334', 'just testing                        \r\n                       ', '2017-11-27 13:20:11'),
('story/008', 'story_008.jpeg', 'chidibaby@gmail.com', 'emmanuel', 'Cena', '09087654334', 'testing two                        \r\n                       ', '2017-11-27 14:18:22'),
('story/009', 'story_009.jpeg', 'jackson@gmail.com', 'ikeogu', 'aderson', '09021805432', 'i have a confession to make                        \r\n                       ', '2017-11-27 14:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `share_testimony`
--

CREATE TABLE IF NOT EXISTS `share_testimony` (
  `testimony_id` varchar(25) NOT NULL,
  `passport` varchar(30) NOT NULL,
  `email` varchar(70) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  `testimony` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`testimony_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `share_testimony`
--

INSERT INTO `share_testimony` (`testimony_id`, `passport`, `email`, `first_name`, `last_name`, `phone`, `testimony`, `date`) VALUES
('Testimony/001', '', '', '', NULL, '', '                        ', '2017-11-25 17:50:17'),
('Testimony/0002', '', 'chidibaby@gmail.com', 'jackson ', 'Cena', '09087654334', 'God bless Ngofor helpin g me out of this issue.                         ', '2017-11-25 17:52:50'),
('Testimony/002', '', 'jackson@gmail.com', 'emmanuel', NULL, '09087654334', ' this is the most lucrative help i have ever seen. thanks to the councilor i got , that brought me out of  distress                       ', '2017-11-25 17:57:19'),
('Testimony/003', '', '', '', NULL, '', '                        ', '2017-11-25 18:00:24'),
('Testimony/004', '', 'jackson@gmail.com', 'uche', NULL, '09021805432', 'fdjfddffdsaaas                        \r\n                       ', '2017-11-26 22:08:01'),
('Testimony/005', 'Testimony_005.jpeg', 'kalu@gmail.com', 'ikeogu', 'chidera', '09087654334', 'testimony time                        \r\n                       ', '2017-11-27 14:28:29'),
('Testimony/006', 'Testimony_006.jpeg', 'ikeogu322@gmail.com', 'ikeogu', 'Ikeogu', '11111111111', 'Body they sweet me                        \r\n                       ', '2017-11-27 14:31:42');
