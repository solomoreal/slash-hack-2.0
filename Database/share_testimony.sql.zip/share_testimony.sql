-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 28, 2017 at 02:28 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `slash_hack`
--

-- --------------------------------------------------------

--
-- Table structure for table `share_testimony`
--

CREATE TABLE IF NOT EXISTS `share_testimony` (
  `testimony_id` varchar(25) NOT NULL,
  `passport` varchar(30) NOT NULL,
  `email` varchar(70) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  `testimony` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`testimony_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `share_testimony`
--

INSERT INTO `share_testimony` (`testimony_id`, `passport`, `email`, `first_name`, `last_name`, `phone`, `testimony`, `date`) VALUES
('Testimony/001', '', '', '', NULL, '', '                        ', '2017-11-25 17:50:17'),
('Testimony/0002', '', 'chidibaby@gmail.com', 'jackson ', 'Cena', '09087654334', 'God bless Ngofor helpin g me out of this issue.                         ', '2017-11-25 17:52:50'),
('Testimony/002', '', 'jackson@gmail.com', 'emmanuel', NULL, '09087654334', ' this is the most lucrative help i have ever seen. thanks to the councilor i got , that brought me out of  distress                       ', '2017-11-25 17:57:19'),
('Testimony/003', '', '', '', NULL, '', '                        ', '2017-11-25 18:00:24'),
('Testimony/004', '', 'jackson@gmail.com', 'uche', NULL, '09021805432', 'fdjfddffdsaaas                        \r\n                       ', '2017-11-26 22:08:01'),
('Testimony/005', 'Testimony_005.jpeg', 'kalu@gmail.com', 'ikeogu', 'chidera', '09087654334', 'testimony time                        \r\n                       ', '2017-11-27 14:28:29'),
('Testimony/006', 'Testimony_006.jpeg', 'ikeogu322@gmail.com', 'ikeogu', 'Ikeogu', '11111111111', 'Body they sweet me                        \r\n                       ', '2017-11-27 14:31:42');
